package com.snhu.sslserver;
import java.security.MessageDigest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}

}
//FIXME: Add route to enable check sum return of static data example:  String data = "Hello World Check Sum!";
@RestController
class ServerController{
//FIXME:  Add hash function to return the checksum value for the data string that should contain your name.    
    @RequestMapping("/hash")
    public String myHash(){
    	String data = "Hello Matthew Keaton!";
    	//initialize hashValue outside of try block -MK
    	String hashValue = "";
    	//handle exception -MK
    	try {

    		//create object of MessageDigest -MK
    		MessageDigest md = MessageDigest.getInstance("SHA-256");
    		//pass data to digest object -MK
    		md.update(data.getBytes());
    		//generate message digest using digest() -MK
    		byte[] digest = md.digest();
    		//convert hash value to hex using bytesToHex function -MK
    		hashValue = bytesToHex(digest);
    
    	
    	}
    	//exception to catch and return error message -MK
    	catch (Exception e) {
    		return e.getMessage();
    	}
    	//return data, Algorithm, and hashValue -MK
        return "<p>data:" + data +
        		"<p>Name of Cipher Algorithm used: SHA-256, Checksum Value: " + hashValue + "</p>";
    }
    //add method for bytesToHex -MK
    private String bytesToHex(byte[] bytes) {
        StringBuilder hexString = new StringBuilder();
        //loop through each byte in the bytes array -MK
        for (int i = 0; i < bytes.length; ++i) {
        	//convert to 2 digit hexadecimal and add to hexString -MK
            hexString.append(String.format("%02x", bytes[i]));
        }
        //convert to a string and return hexadecimal -MK
        return hexString.toString();
    }
}

